<?php
const STATUS_ACTIVE      = 'active';
const STATUS_INACTIVE    = 'inactive';

const HOME_PAGE = 'home';
const ABOUT_COMPANY_PAGE = 'about-company';
const ABOUT_ME_PAGE = 'about-me';
const SAMPLE_SCRIPT_PAGE = 'sample_script';
const CONTACT_DETAILS_PAGE = 'contact-details';

const WARRANTY_APPLIED = 'applied';
const WARRANTY_CLAIMED = 'claimed';
const WARRANTY_CANCELLED = 'cancelled';
